---
name: Feature request
about: Suggest an idea for Smilei
title: ''
labels: feature-request
assignees: ''

---

## The problem and the context

I cannot do ...

## The solution

I would like to ...

## Failed attempts

I have tried other things already ...
